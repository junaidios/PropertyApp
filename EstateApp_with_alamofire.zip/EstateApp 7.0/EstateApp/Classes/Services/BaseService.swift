//
//  BaseService.swift
//  EstateApp
//
//  Created by JayD on 21/06/2015.
//  Copyright (c) 2015 Waqar Ahsan. All rights reserved.
//

import UIKit


typealias successBlock = (data: AnyObject?) -> Void
typealias failureBlock = (error: NSError?)   -> Void

class BaseService: NSObject {
   
}
